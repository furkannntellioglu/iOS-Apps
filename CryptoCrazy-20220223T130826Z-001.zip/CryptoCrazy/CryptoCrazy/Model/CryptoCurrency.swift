//
//  CryptoCurrency.swift
//  CryptoCrazy
//
//  Created by user213741 on 2/23/22.
//

import Foundation

struct CryptoCurrency: Decodable {      // Decodable, Encodable, Codable

    let currency: String
    let price: String

}
